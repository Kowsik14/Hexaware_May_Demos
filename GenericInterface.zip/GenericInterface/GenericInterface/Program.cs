﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterface
{
    interface ISwapper<T>
    {
        void Swap(ref T item1, ref T item2);
    }
    class IntSwapper : ISwapper<int>
    {
        public void Swap(ref int item1, ref int item2)
        {
            int Temp = item1;
            item1 = item2;
            item2 = Temp;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int i = 10, j = 20;
            IntSwapper Obj = new IntSwapper();
            Obj.Swap(ref i, ref j);
            Console.WriteLine("i={0}, j={1}", i, j);

            Console.ReadKey();
        }
    }
}
