﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicityInterfaceImplementation
{
    interface IVersion1
    {
        void GetVersion();
    }
    interface IVersion2
    {
        void GetVersion();
    }
    class Version : IVersion1, IVersion2
    {
        void IVersion1.GetVersion()
        {
            Console.WriteLine("IVersion 1 executed");
        }
        void IVersion2.GetVersion()
        {
            Console.WriteLine("IVersion 2 executed");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Version V = new Version();

            IVersion1 V1 = V;
            IVersion2 V2 = V;

            V1.GetVersion();
            V2.GetVersion();

            Console.ReadKey();
        }
    }
}
