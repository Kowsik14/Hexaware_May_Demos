﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericAndConstraints
{
    class Shape
    {

    }
    class Circle : Shape
    {

    }
    class Rectangle : Shape
    {

    }
    class Customer
    {

    }

    class MyStack<T> where T : class
    {
        public void Push(T item)
        {

        }
        public T Pop()
        {
            return default(T);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            //MyStack<int> Obj = new MyStack<int>();

            //MyStack<string> Obj1 = new MyStack<string>();

            MyStack<Shape> ObjShapes = new MyStack<Shape>();
            MyStack<Circle> ObjCirlce = new MyStack<Circle>();
            MyStack<Rectangle> ObjRectangles = new MyStack<Rectangle>();
            MyStack<Customer> ObjCustomers = new MyStack<Customer>();


        }
    }
}
