﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] CollegeData = new int[3][];
            CollegeData[0] = new int[2];
            CollegeData[1] = new int[3];
            CollegeData[2] = new int[1];

            CollegeData[0][0] = 40;
            CollegeData[0][1] = 50;

            CollegeData[1][0] = 50;
            CollegeData[1][1] = 50;
            CollegeData[1][2] = 50;

            CollegeData[2][0] = 60;
            
            foreach(int[] item in CollegeData)
            {
                foreach(int value in item)
                {
                    Console.WriteLine(value);
                }
                Console.WriteLine();
            }

            Console.ReadKey();


        }
    }
}
