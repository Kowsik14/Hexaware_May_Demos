﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EmployeeLibrary;
namespace EmployeeConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Obj = new Employee();
            Obj.Id = 101;
            Obj.Name = "Jojo Jose";
            string details = Obj.GetDetails();
            Console.WriteLine(details);
            Console.ReadKey();
        }
    }
}
