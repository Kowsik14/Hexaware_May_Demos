﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HasARelationship
{
    interface ICustomer
    {
        int Id { get; set; }
        string Name { get; set; }
    }
    class Customer : ICustomer
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    class PremiumCustomer : Customer
    {

    }
    class CustomerVerion1: Customer
    {

    }
    
}
