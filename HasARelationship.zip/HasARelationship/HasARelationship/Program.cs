﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HasARelationship
{
    class Program
    {
        static void Main(string[] args)
        {
            Product[] Products = new Product[] { new Product(), new Product() };
            Products[0].Id = 101;
            Products[0].Name = "Mobile";

            Customer Customer = new Customer();
            Customer.Id = 10000;
            Customer.Name = "Jojo";

            Order Obj = new Order();
            Obj.Id = 1;
            Obj.Cust = Customer;
            Obj.Products = Products;

            Obj.Print();








            //Order Obj1 = new Order();
            //Order Obj2 = new Order(10);
            //Order Obj3 = new Order(Customer, 10);








            Console.ReadKey();
        }
    }
}
