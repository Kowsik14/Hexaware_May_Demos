﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HasARelationship
{
    class Order
    {
        public int Id { get; set; }
        public ICustomer Cust { get; set; }
        public Product[] Products { get; set; }

        public Order(ICustomer cust)
        {
            Cust = cust;            
        }

        public Order(int noOfProducts)
        {
            Cust = new Customer();
            Products = new Product[noOfProducts];
        }
        public Order(Customer cust, int noOfProducts)
        {
            this.Cust = cust;
            Products = new Product[noOfProducts];
        }

        public void Print()
        {
            Console.WriteLine("Id = " + Id);
            Console.WriteLine("Cust Id = " + Cust.Id);
            Console.WriteLine("Cust Name = " + Cust.Name);

            foreach(Product p in Products)
            {
                Console.WriteLine("Id = {0}, Name={1}", p.Id, p.Name);
            }
        }
    }
}
