﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorsDemo
{
    class Employee
    {
        public string Name;
        public int Age;
        public static string CompanyName;

        public Employee()
        {
            Age = 18;
        }
        static Employee()
        {
            CompanyName = "Hexaware";
        }
        public Employee(string n, int Age)
        {
            Name = n;
            this.Age = Age;
        }
        public void Print()
        {
            Console.WriteLine("Name={0}, Age={1}, Company={2}", Name, Age, CompanyName);
        }
    }
}
