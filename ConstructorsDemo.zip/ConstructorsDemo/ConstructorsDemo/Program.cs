﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Obj = new Employee();
            Obj.Print();


            Employee Obj1 = new Employee();
            Obj1.Name = "Jojo";
            Obj1.Print();

            Employee Obj2 = new Employee("Sam",22);
            Obj2.Print();

            Console.ReadKey();
        }
    }
}
