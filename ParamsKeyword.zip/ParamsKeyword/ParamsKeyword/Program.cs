﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParamsKeyword
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] Nos = new int[] {10,20,30 };
            DoSum(Nos);

            int a = 1, b = 2, c = 3;
            DoSum(a, b, c);

            DoSum(2, 4, 6, 8, 10);

            DoSum();

            Console.ReadKey();
        }
        public static void DoSum(params int[] numbers)
        {
            int sum = 0;
            foreach(int number in numbers)
            {
                sum += number;
                //sum = sum + number;
            }
            Console.WriteLine("Sum = {0}", sum);
        }
    }
}
