﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
namespace DirectoryInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Creating a new directory if not present
                //DirectoryInfo dir = new DirectoryInfo("C:\\Hexaware");
                //if (!dir.Exists)
                //{
                //    dir.Create();
                //}

                //retriving details from d: drive
                DirectoryInfo info = new DirectoryInfo("C:\\DXCMarchBatch_Demos\\CSharp");
                Console.WriteLine("Exists : {0}", info.Exists);
                Console.WriteLine("Full Path : {0}", info.FullName);
                Console.WriteLine("Root : {0}", info.Root.Name);

                ////Get the top Level Directories Starting with A
                DirectoryInfo[] directories = info.GetDirectories();
                Console.WriteLine("---------------------------------------");
                Console.WriteLine("\t\tDirectories");
                Console.WriteLine("---------------------------------------");
                foreach (DirectoryInfo di in directories)
                {
                    Console.WriteLine("{0}", di.Name);
                }


                FileInfo[] files = info.GetFiles();
                Console.WriteLine("---------------------------------------");
                Console.WriteLine("\t\tFiles");
                Console.WriteLine("---------------------------------------");
                foreach(FileInfo fi in files)
                {
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", fi.Name, fi.Length, fi.Extension);
                }

               
            }
            catch (DirectoryNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
