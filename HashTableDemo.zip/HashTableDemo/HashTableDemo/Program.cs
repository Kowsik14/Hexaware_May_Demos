﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;
namespace HashTableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable ObjTable = new Hashtable();
            ObjTable.Add(101, "Jojo");
            ObjTable.Add(100, "Sam");
            ObjTable.Add(103, "Sarah");

            Console.WriteLine("Count : " + ObjTable.Count);

            foreach(object key in ObjTable.Keys)
            {
                Console.WriteLine("Key ={0}, \t Value={1}",key,ObjTable[key]);
            }


            ObjTable.Remove(103);
            Console.WriteLine("Count after remove : " + ObjTable.Count);
            Console.ReadKey();


        }
    }
}
