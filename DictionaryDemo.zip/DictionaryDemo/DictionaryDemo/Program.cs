﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> EmployeesDetails = new Dictionary<int, string>();

            EmployeesDetails.Add(101, "Jojo");
            EmployeesDetails.Add(102, "Sam");
            EmployeesDetails.Add(103, "Sarah");
            //EmployeesDetails.Add("Arun", 1234);

            foreach(KeyValuePair<int,string> keyvalue in EmployeesDetails)
            {
                Console.WriteLine(keyvalue.Key + "\t" + keyvalue.Value);
            }


            EmployeesDetails.Remove(101);
            Console.WriteLine("Count after remove : " + EmployeesDetails.Count);

            Console.ReadKey();
        }
    }
}
