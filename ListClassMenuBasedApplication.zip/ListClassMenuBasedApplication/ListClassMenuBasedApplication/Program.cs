﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListClassMenuBasedApplication
{
    class Program
    {
       static List<Product> ObjProductsList = new List<Product>();

        static void Main(string[] args)
        {

            int Choice = 0;
            do
            {
                Console.WriteLine("\n\n");
                Console.WriteLine("\t\t1.Add");
                Console.WriteLine("\t\t2.View All");
                Console.WriteLine("\t\t3.Find");
                Console.WriteLine("\t\t4.Remove");
                Console.WriteLine("\t\t5.Exit");

                Console.WriteLine("\n\nEnter your choice");
                Choice = int.Parse(Console.ReadLine());

                switch (Choice)
                {
                    case 1:AddProduct(); break;
                    case 2:ViewProducts(); break;
                    case 3:FindProduct(); break;
                    case 4:RemoveProduct(); break;
                    default: Console.WriteLine("Invalid input"); break;
                }
            } while (Choice != 5);

        }
        static void AddProduct()
        {
            Product ObjProduct = new Product();

            Console.WriteLine("Enter Id");
            ObjProduct.Id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Name");
            ObjProduct.Name = Console.ReadLine();

            ObjProductsList.Add(ObjProduct);

        }

        static void ViewProducts()
        {
            Console.WriteLine("\n----------------------------------");
            Console.WriteLine("Id\t\tName");
            Console.WriteLine("----------------------------------");
            foreach (Product product in ObjProductsList)
            {
                Console.WriteLine(product.Id + "\t\t" + product.Name);
            }
            Console.WriteLine("Total count : " + ObjProductsList.Count);
        }
        static void FindProduct()
        {
            int Id = 0;
            Console.WriteLine("Enter Id of product to search");
            Id = int.Parse(Console.ReadLine());

            bool IsFound = false;
            foreach(Product product in ObjProductsList)
            {
                if (product.Id == Id)
                {
                    Console.WriteLine("Product found");
                    Console.WriteLine("Id={0}\t\tName={1}", product.Id, product.Name);
                    IsFound = true;
                    break;
                }                
            }
            if (!IsFound)
            {
                Console.WriteLine("Not found");
            }
            
        }
        static void RemoveProduct()
        {
            int Id = 0;
            Console.WriteLine("Enter Id of product to delete");
            Id = int.Parse(Console.ReadLine());

            bool Removed = false;
            for (int i = 0; i < ObjProductsList.Count; i++)
            {
                if (ObjProductsList[i].Id == Id)
                {
                    ObjProductsList.RemoveAt(i);
                    Removed = true;
                    break;

                }
            }
            if (!Removed)
            {
                Console.WriteLine("Not found");
            }
        }

        
    }
}
