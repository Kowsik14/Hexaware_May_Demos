﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectInitializer
{
    class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double UnitPrice { get; set; }
        private double Amount { get; set; }
        public Product()
        {

        }
        public Product(int id)
        {
            this.Id = id;
        }
        public override string ToString()
        {
            return "Id= " + Id + ", Name = " + Name +", Unitprice = "+UnitPrice;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //C# 2.0
            Product P = new Product();
            P.Id = 101;
            P.Name = "Pen";
            P.UnitPrice = 100;


            Product P1 = new Product(102);
            P1.Name = "Duster";
            P1.UnitPrice = 100;


            //C# 3.0
            Product P2 = new Product() { Id = 103, Name = "Laptop", UnitPrice = 200 };
            Product P3 = new Product(104) { Name = "Keyboard", UnitPrice = 150 };
            var P4 = new Product(105) { Name = "Mouse" };
            P4.UnitPrice = 75;

            P3.Name = "Pendrive";

            //Product P5 = new Product();
            //P5 ={Id=101 };

            Console.WriteLine(P);
            Console.WriteLine(P.ToString());
            Console.WriteLine(P1);
            Console.WriteLine(P2);
            Console.WriteLine(P3);
            Console.WriteLine(P4);





            var ObjProduct = new Product() { Id = 10, Name = "Test", UnitPrice = 100 };
            Console.WriteLine(ObjProduct);
            Console.ReadKey();

        }
    }
}
