﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
    public class DXCException : ApplicationException
    {
        public DXCException() : base()
        {

        }
        public DXCException(string message) : base(message)
        {

        }
        public DXCException(string message, Exception inner) : base(message, inner)
        {

        }
    }
}
