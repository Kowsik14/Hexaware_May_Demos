﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
    class Employee
    {
        private int _age;

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                if (value < 18 || value > 58)
                {
                    
                    throw new DXCException("Age must be between 18 and 58");
                }
                else
                {
                    _age = value;
                }
            }
        }

    }
}
