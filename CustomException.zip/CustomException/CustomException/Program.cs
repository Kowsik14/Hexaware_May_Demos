﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee Obj = new Employee();
                Obj.Age = 22;
                Console.WriteLine(Obj.Age);
            }
            catch(DXCException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
