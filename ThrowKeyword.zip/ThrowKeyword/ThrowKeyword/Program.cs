﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThrowKeyword
{
    class Employee
    {
        private int _age;

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                if (value < 18 || value > 58)
                {
                    //ArgumentException ex = new ArgumentException("Invalid Age");
                    //throw ex;
                    throw new ArgumentException("Age must be between 18 and 58");
                }
                else
                {
                    _age = value;
                }
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee Obj = new Employee();
                Obj.Age = 15;
                Console.WriteLine(Obj.Age);
            }
            catch(ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
