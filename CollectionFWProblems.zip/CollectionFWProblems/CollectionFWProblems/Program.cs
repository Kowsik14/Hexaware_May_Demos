﻿using System;

using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Collections;
namespace CollectionFWProblems
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList Obj = new ArrayList();
            Obj.Add(10);
            Obj.Add(20);
            Obj.Add(30);
            Obj.Add("Jojo");

            int Sum = 0;
            foreach(object value in Obj)
            {
                Sum = Sum + Convert.ToInt32(value);
            }
            Console.WriteLine("Sum = " + Sum);
            Console.ReadKey();
        }
    }
}
