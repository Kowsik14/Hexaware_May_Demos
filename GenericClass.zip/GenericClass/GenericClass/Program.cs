﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericClass
{
    class Helper<T> 
    {
        public void Swap(ref T param1, ref T param2)
        {
            T Temp;
            Temp = param1;
            param1 = param2;
            param2 = Temp;


        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            Helper<int> Obj = new Helper<int>();

            int i = 10, j = 20;
            Obj.Swap(ref i, ref j);

            Console.WriteLine("i={0}, j={1}", i, j);


            Helper<bool> Obj1 = new Helper<bool>();
            bool b1 = true, b2 = false;
            Obj1.Swap(ref b1, ref b2);
            Console.WriteLine("b1={0}, b2={1}", b1, b2);


            Console.ReadKey();

        }
    }
}
