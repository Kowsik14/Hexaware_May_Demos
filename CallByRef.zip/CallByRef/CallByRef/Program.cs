﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallByRef
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10, y=20;
            Console.WriteLine("x={0}, y={1}", x, y);
            Swap(ref x, ref y);
            Console.WriteLine("x={0}, y={1}", x, y);
            Console.ReadKey();
        }

        public static void Swap(ref int a, ref int b)
        {
            int Temp = a;
            a = b;
            b = Temp;
            Console.WriteLine("a={0}, b={1}", a, b);

        }
    }
}
