﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListClassWithObjects
{
    class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Customer(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {


            List<Customer> ObjCustomersList = new List<Customer>();

            ObjCustomersList.Add(new Customer(101, "Jojo"));

            Customer Cust = new Customer(102, "Sam");
            ObjCustomersList.Add(Cust);

            int Id;
            string Name;

            Console.WriteLine("Enter id");
            Id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter  name");
            Name = Console.ReadLine();

            Customer CustA = new Customer(Id, Name);
            ObjCustomersList.Add(CustA);

            foreach(Customer customer in ObjCustomersList)
            {
                Console.WriteLine(customer.Id + " \t " + customer.Name);
            }



            Console.ReadKey();
        }
        
    }
}
