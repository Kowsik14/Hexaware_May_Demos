﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptionalParameters
{
    class Program
    {
        static void Main(string[] args)
        {
            Print(101, "Jojo", 25);
            Print(102, "Sam");
            Print(name: "Sarah", id: 103);
            Console.ReadKey();
        }
        static void Print(int id, string name, int age=21)
        {
            Console.WriteLine("Id={0}, Name={1}, Age={2}", id, name, age);
        }
    }
}
