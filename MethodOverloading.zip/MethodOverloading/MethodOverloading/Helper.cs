﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloading
{
    class Helper
    {
        public int Add(int a, int b)
        {
            return a + b;
        }
        
        public string Add(string s1, string s2)
        {
            return s1 + s2;
        }
    }
}
