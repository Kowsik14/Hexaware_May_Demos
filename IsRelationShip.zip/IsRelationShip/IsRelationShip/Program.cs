﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsRelationShip
{

    class Shape
    {
        protected double _area;
        public double Area
        {
            get
            {
                return _area;
            }
        }
    }
    class Rectangle : Shape
    {
        public double Length { get; set; }
        public double Breath { get; set; }

        public void CalculateArea()
        {
            _area = Length * Breath;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rec = new Rectangle();
            rec.Length = 10;
            rec.Breath = 2;
            rec.CalculateArea();
            //rec.Area = 100;
            Console.WriteLine(rec.Area);

            Console.ReadKey();
        }
    }
}
