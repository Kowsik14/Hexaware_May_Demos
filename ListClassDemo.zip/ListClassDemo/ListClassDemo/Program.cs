﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListClassDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> ObjNumbers = new List<int>();
            ObjNumbers.Add(10);
            ObjNumbers.Add(20);
            ObjNumbers.Add(30);
            ObjNumbers.Add(40);

            Console.WriteLine("Count : " + ObjNumbers.Count);


            int sum = 0;
            foreach(int number in ObjNumbers)
            {
                Console.WriteLine(number);
                sum = sum + number;
            }
            Console.WriteLine("Sum = " + sum);


            ObjNumbers.Remove(10);
            Console.WriteLine("Count after remove : " + ObjNumbers.Count);

            Console.ReadKey();
        }
    }
}
