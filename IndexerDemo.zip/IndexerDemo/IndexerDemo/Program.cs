﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Obj = new Employee();

            //assign values
            Obj[0] = "jojo";
            Obj[1] = "20";

            Console.WriteLine("Name = {0}, id={1}", Obj[0], Obj[1]);

            Console.ReadKey();

        }
    }
}
