﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class Employee
    {
        string name;
        int id;

        public string this[int index]
        {
            get
            {
                if (index == 0)
                {
                    return name;
                }
                else if (index == 1)
                {
                    return id.ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                if (index == 0)
                {
                    name = value;
                }
                else if (index == 1)
                {
                    id = int.Parse(value);
                }
            }
        }
    }
}
