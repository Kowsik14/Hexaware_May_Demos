﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimensionArray
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] EmployeeNames = new string[] { "Jojo", "Sam", "Sarah" };

            
            Console.WriteLine(EmployeeNames.Length);

            for(int index = 0; index < EmployeeNames.Length; index++)
            {
                Console.WriteLine(EmployeeNames[index]);
            }

            foreach(string EmployeeName in EmployeeNames)
            {
                Console.WriteLine(EmployeeName);
            }
            Console.ReadKey();
        }
    }
}
