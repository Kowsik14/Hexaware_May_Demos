﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Runtime.Serialization;

using System.Xml.Serialization;
namespace XMLSerialization
{
    class Program
    {
        static void Main(string[] args)
        {            
            UserInfo Info = new UserInfo();
            
            
            Info.Username = "jojo";
            Info.Email = "Jojo@wipro.com";
            Info.Password = "jojo123";

            Serialize(Info);


            UserInfo Data = Deserialize();
            Console.WriteLine("{0}, {1}, {2}", Data.Username, Data.Email, Data.Password);

            Console.ReadKey();

        }

        static void Serialize(UserInfo obj)
        {
            using (FileStream fs = new FileStream("e:\\Userinfo.xml", FileMode.Create, FileAccess.Write))
            {
                XmlSerializer formatter = new XmlSerializer(typeof(UserInfo));
                formatter.Serialize(fs, obj);
            }
        }

        static UserInfo Deserialize()
        {
            UserInfo Ui = new UserInfo();
            using (FileStream fs = new FileStream("e:\\Userinfo.xml", FileMode.Open, FileAccess.Read))
            {
                XmlSerializer formatter = new XmlSerializer(typeof(UserInfo));

                Ui = (UserInfo)formatter.Deserialize(fs);
            }
            return Ui;
        }
    }
}
