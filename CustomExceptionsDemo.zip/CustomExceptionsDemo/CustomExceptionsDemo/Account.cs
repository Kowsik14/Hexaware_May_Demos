﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionsDemo
{
    public class Account
    {
        private double _Balance;
        public double Balance
        {
            get { return _Balance; }
        }

        public double Deposit(double amount)
        {
            _Balance += amount;
            return _Balance;
        }

        public double Withdraw(double amount)
        {
            if (_Balance - amount < 0) {
                //throw new ArithmeticException("Insufficient balance");
                throw new InsufficientBalanceException("Negative balance not allowed");
            }
            _Balance -= amount;
            return _Balance;
        }
    }
}
