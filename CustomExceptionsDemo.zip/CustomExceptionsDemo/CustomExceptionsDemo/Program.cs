﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                
                Account ObjAccount = new Account();
                Console.WriteLine(ObjAccount.Deposit(1000));
                Console.WriteLine(ObjAccount.Withdraw(10000));
            }
            catch(InsufficientBalanceException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                Console.WriteLine("Stack Trace");
                Console.WriteLine(ex.StackTrace);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                Console.WriteLine("Stack Trace");
                Console.WriteLine(ex.StackTrace);
            }

            Console.ReadKey();
        }
    }
}
