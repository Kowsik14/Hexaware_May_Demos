﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitlyTypedVariable
{
    class Product
    {

    }
    class Program
    {

        static void Main(string[] args)
        {
            var Age = 20;
            var Name = "Jojo";


            string[] Names = new string[10];
            var NamesList = new string[10];


            //C# 2.0
            Dictionary<int, Product> Products = new Dictionary<int, Product>();

            //C# 3.0
            var ProductsObj = new Dictionary<int, Product>();


            var ObjList = new List<Product>();


            //C# 2.0
            Product P = new Product();

            //C# 3.0
            var ObjP = new Product();

            var Obj = Display(ObjP);


            //C# 2.0
            foreach(Product item in ObjList)
            {

            }

            //C# 3.0
            foreach(var item in ObjList)
            {

            }

            //Restrictions
            var i = 10;
            //i = "Jojo";
            i = 20;

            //var Obj = null;
            //var a, b, c;

        }
        public static Product Display(Product item)
        {
            return new Product();
        }
    }
}
