﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethod
{
    class Helper
    {
        public void Swap<T>(ref T param1, ref T param2)
        {
            T Temp;
            Temp = param1;
            param1 = param2;
            param2 = Temp;

            //param1 = param1 + param2;
            //param2 = param1 - param2;
            //param1 = param1 - param2;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            Helper Obj = new Helper();

            int i = 10, j = 20;
            Obj.Swap<int>(ref i, ref j);

            Console.WriteLine("i={0}, j={1}", i, j);


            bool b1 = true, b2 = false;
            Obj.Swap<bool>(ref b1, ref b2);
            Console.WriteLine("b1={0}, b2={1}", b1, b2);


            Console.ReadKey();
        }
    }
}
