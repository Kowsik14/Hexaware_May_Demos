﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumerations
{

    class Program
    {
        static void Main(string[] args)
        {

            EmployeeType EmpType;

            EmpType = EmployeeType.Freelancer;

            Console.WriteLine("Employee Type : " + EmpType);
            Console.WriteLine("Employee Type code : " + (int)EmpType);

            Console.WriteLine("Enter employee type");
            string code = Console.ReadLine();
            EmpType = (EmployeeType)Enum.Parse(typeof(EmployeeType), code);
           
            switch (EmpType)
            {
                case EmployeeType.Permanent:
                    Console.WriteLine("You are a permanent employee");
                    break;
                case EmployeeType.Contract:
                    Console.WriteLine("You are a contract employee");

                    break;
                case EmployeeType.Freelancer:
                    Console.WriteLine("You are a freelancer employee");
                    break;
                default:
                    Console.WriteLine("You are a guest");
                    break;
            }

            Console.ReadKey();
        }
    }
}
