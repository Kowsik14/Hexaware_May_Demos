﻿enum EmployeeType
{
    Permanent = 10, Contract = 20, Freelancer = 30
}