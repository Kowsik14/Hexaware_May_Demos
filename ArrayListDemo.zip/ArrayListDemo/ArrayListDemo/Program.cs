﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;

namespace ArrayListDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            ArrayList ObjNames = new ArrayList();
            ObjNames.Add("Jojo");
            ObjNames.Add("Sam");
            ObjNames.Add("Sarah");
            

            Console.WriteLine("Count : " + ObjNames.Count);


            Console.WriteLine("Items in the list");
            for(int i = 0; i < ObjNames.Count; i++)
            {
                Console.WriteLine(ObjNames[i]);
            }

            Console.WriteLine("Items in the list using Foreach");
            foreach(object item in ObjNames)
            {
                Console.WriteLine(item);
            }


            ObjNames.Remove("Jojo");
            Console.WriteLine("Count after remove : " + ObjNames.Count);
            Console.WriteLine("Capacity : " + ObjNames.Capacity);
            Console.ReadKey();

        }
    }
}
