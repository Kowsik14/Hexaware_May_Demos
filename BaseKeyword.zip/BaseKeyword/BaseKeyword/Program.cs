﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseKeyword
{
    class Mobile
    {
        public string Model { get; set; }
        public Mobile(string model)
        {
            this.Model = model;
        }
        public Mobile()
        {
            Model = "Not specified";
        }
    }

    class SmartPhone : Mobile
    {
        public string CameraDetails { get; set; }
        public SmartPhone(string model, string cameraDetails) : base(model)
        {
            this.CameraDetails = cameraDetails;
        }
        public SmartPhone():base()
        {

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            SmartPhone Obj = new SmartPhone("Nokia Lumia", "12 Mega px");
            Console.WriteLine(Obj.Model + " " + Obj.CameraDetails);

            SmartPhone Obj1 = new SmartPhone();
            Console.WriteLine(Obj1.Model);
            Console.ReadKey();
        }
    }
}
