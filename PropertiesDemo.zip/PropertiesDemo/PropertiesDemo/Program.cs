﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Obj = new Employee();
            Obj.Name = "Jojo";
            Obj.Age = 25;

            Console.WriteLine("{0}\t{1}", Obj.Name, Obj.Age);
            Console.ReadKey();
        }
    }
}
