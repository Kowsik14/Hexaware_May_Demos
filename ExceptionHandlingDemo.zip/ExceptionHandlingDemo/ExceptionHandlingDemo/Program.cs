﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            try
            {
                Console.WriteLine("Enter a and b's value");
                a = int.Parse(Console.ReadLine());
                b = int.Parse(Console.ReadLine());
                if (b > 0)
                {
                    c = a / b;
                }
                else
                {
                    c = 0;
                }
                Console.WriteLine("Result = " + c);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("CLR Message = " + ex.Message);
                Console.WriteLine("STACK TRACE");
                Console.WriteLine(ex.StackTrace);
                Console.WriteLine("Error");
            }
            catch(Exception ex)
            {
                Console.WriteLine("CLR Message = " + ex.Message);
                Console.WriteLine("STACK TRACE");
                Console.WriteLine(ex.StackTrace);

                Console.WriteLine("Generic error");
            }
            finally
            {
                Console.WriteLine("Closing program");
            }
            Console.ReadKey();
        }
    }
}
