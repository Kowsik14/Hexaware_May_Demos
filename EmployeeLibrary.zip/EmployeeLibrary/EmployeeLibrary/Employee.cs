﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string GetDetails()
        {
            return string.Format("Name={0}, Id={1}", Name, Id);
        }
    }
}
