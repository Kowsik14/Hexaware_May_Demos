﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDisposableDemo
{
    class FileManager : IDisposable
    {
        private string fileName;
        public FileManager(string fileName)
        {
            this.fileName = fileName;
        }
        public void WriteData(string data)
        {
            Console.WriteLine("Written data: " + data);
        }

        public void Dispose()
        {
            Console.WriteLine("Object destroyed");
            fileName = null;
        }
        
    }
}
