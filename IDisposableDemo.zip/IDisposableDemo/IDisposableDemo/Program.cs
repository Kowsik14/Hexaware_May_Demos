﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDisposableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DoWork();
            
            Console.ReadKey();
        }
        static void DoWork()
        {
            //FileManager FM = new FileManager("C:\\Sample.txt");
            //FM.WriteData("Hello");
            //FM.Dispose();

            using (FileManager FM1=new FileManager("C:\\Demo.ppt"))
            {
                FM1.WriteData("Done");
            }


        }
    }
}
