﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
namespace FileStreamsAndBinaryReaderAndBinaryWriter
{
    class Program
    {
        static void Main(string[] args)
        {
            //WriteData();
            ReadData();

            Console.ReadKey();
        }

        private static void ReadData()
        {
            using (FileStream fileStream02 = new FileStream("E:\\test.dat", FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream02);
                string name = binaryReader.ReadString();
                int age = binaryReader.ReadInt32();
                int salary = binaryReader.ReadInt32();
                Console.WriteLine("Name : {0}, Age = {1}, Salary = {2}", name, age, salary);
                binaryReader.Close();
                fileStream02.Close();
            }
        }

        private static void WriteData()
        {
            using (FileStream fileStream01 = new FileStream("E:\\test.dat", FileMode.Create, FileAccess.Write))
            {
                BinaryWriter binaryWriter = new BinaryWriter(fileStream01);
                binaryWriter.Write("Jojo");
                binaryWriter.Write(25);
                binaryWriter.Write(40000);
                binaryWriter.Close();
                fileStream01.Close();
            }
        }
    }
}
