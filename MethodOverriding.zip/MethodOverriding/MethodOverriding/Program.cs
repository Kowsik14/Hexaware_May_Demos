﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverriding
{
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        protected double baseSalaryPerDay;
        public virtual double CalculateSalary(int noOfDaysWorked)
        {
            baseSalaryPerDay = 1000;
            return baseSalaryPerDay * noOfDaysWorked;
        }
    }
    class ContactEmployee : Employee
    {
        public override double CalculateSalary(int noOfDaysWorked)
        {
            double baseSalaryPerHour = 250;
            double NoOfHoursWorked = noOfDaysWorked * 8;
            return baseSalaryPerHour * NoOfHoursWorked;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee Obj = new Employee();
            Obj.Id = 101;
            Obj.Name = "Jojo";
            Console.WriteLine(Obj.CalculateSalary(22));

            ContactEmployee Obj1 = new ContactEmployee();
            Console.WriteLine(Obj1.CalculateSalary(22));

            Console.ReadKey();
        }
    }
}
