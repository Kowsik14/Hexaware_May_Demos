﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutKeyword
{
    class Program
    {
        static void Main(string[] args)
        {
            string UserName;
            int UserAge;
            GetUserInfo(out UserName, out UserAge);
            Console.WriteLine("Name ={0}, Age={1}", UserName, UserAge);
            Console.ReadKey();
        }

        public static void GetUserInfo(out string name, out int age)
        {
            name = "Jojo Jose";
            age = 25;
            
        }
    }
}
