﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    public class Messenger
    {
        [Obsolete("Use SendMessageAsync() instead of this one")]
        public void SendMessage(string message)
        {
            //TODO: Code to send message
        }

        [Author("Khaleelullah Hussaini Syed")]
        public void SendMessageAsnc(string message)
        {
            //code to send asynchronously
        }
    }
}
