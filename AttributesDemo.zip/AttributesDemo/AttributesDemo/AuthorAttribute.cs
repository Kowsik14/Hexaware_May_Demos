﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public class AuthorAttribute : Attribute
    {
        private string _AuthorName;
        public AuthorAttribute(string authorName)
        {
            this._AuthorName = authorName;
        }
    }
}
