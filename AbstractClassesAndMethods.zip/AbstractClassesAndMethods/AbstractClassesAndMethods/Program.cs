﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassesAndMethods
{
    abstract class Shape
    {
        protected double _area;
        public double Area
        {
            get
            {
                return _area;
            }
        }
        public abstract void CalculateArea();
    }
    class Rectangle : Shape
    {
        public double Length { get; set; }
        public double Breath { get; set; }

        public override void CalculateArea()
        {
            _area = Length * Breath;
        }
    }
    class Circle : Shape
    {
        public double Radius { get; set; }
        public override void CalculateArea()
        {
            _area = 3.1415 * Radius * Radius;
        }
    }
    
    class Square : Shape
    {
        public double Side { get; set; }

        public override void CalculateArea()
        {
            _area = Side * Side;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle r = new Rectangle();
            r.Length = 2;
            r.Breath = 3;
            r.CalculateArea();
            //Console.WriteLine(r.Area);
            CalculateAndPrint(r);

            Circle cir = new Circle();
            cir.Radius = 3;
            cir.CalculateArea();
            //Console.WriteLine(cir.Area);
            CalculateAndPrint(cir);


            Square sq = new Square();
            sq.Side = 4;
            //sq.CalculateArea();
            //Console.WriteLine(sq.Area);
            CalculateAndPrint(sq);

            Console.ReadKey();

        }
        static void CalculateAndPrint(Shape sh)
        {
            sh.CalculateArea();
            Console.WriteLine("Area = " + sh.Area);
        }
    }
}
