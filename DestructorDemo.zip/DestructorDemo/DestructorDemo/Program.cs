﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DestructorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DoWork();
            
            Console.ReadKey();
        }
        static void DoWork()
        {
            FileManager FM = new FileManager("C:\\Sample.txt");
            FM.WriteData("Hello");
        }
    }
}
