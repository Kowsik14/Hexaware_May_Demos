﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DestructorDemo
{
    class FileManager
    {
        private string fileName;
        public FileManager(string fileName)
        {
            this.fileName = fileName;
        }
        public void WriteData(string data)
        {
            Console.WriteLine("Written data: " + data);
        }
        
        ~FileManager()
        {            
            Console.WriteLine("Object destroyed");
            fileName = null;
        }
    }
}
