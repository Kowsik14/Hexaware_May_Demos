﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexers
{
    class Employee
    {
        private int _Id;
        private string _Name;

        public string this[int index]
        {
            get
            {
                if(index==0)
                {
                    return _Id.ToString();
                }
                else if (index == 1)
                {
                    return _Name;
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if (index == 0)
                {
                    _Id = int.Parse(value);
                }
                else if (index == 1)
                {
                    _Name = value;
                }
            }
        }
    }
}
