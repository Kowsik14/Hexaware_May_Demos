﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexers
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Obj = new Employee();
            Obj[0] = "101";
            Obj[1] = "Jojo Jose";

            Console.WriteLine(Obj[0]);
            Console.WriteLine(Obj[1]);

            Console.ReadKey();
        }
    }
}
