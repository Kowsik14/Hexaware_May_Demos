﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesDemo
{
    interface IAction
    {
        void DoWork();
    }
    interface ISaveAction
    {
        void SaveWork();
    }

    class Action : IAction, ISaveAction
    {
        public void DoWork()
        {
            Console.WriteLine("Done");
        }
        public void SaveWork()
        {
            //TODO: Code to save
        }
    }
    

    class Program
    {
        static void Main(string[] args)
        {

            Action Demo = new Action();
            Demo.DoWork();

            
            Console.ReadKey();
        }
    }
}
