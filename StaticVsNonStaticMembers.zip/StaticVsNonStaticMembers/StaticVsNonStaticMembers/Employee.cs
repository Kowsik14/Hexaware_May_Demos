﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticVsNonStaticMembers
{
    class Employee
    {
        public string Name;
        public static string CompanyName;

        public void PrintEmployeeDetails()
        {
            Console.WriteLine("Name = " + Name);
            Console.WriteLine("Company = " + CompanyName);
            
        }

        public static void ChangeCompany(string newCompanyName)
        {
            //Name = newCompanyName;    //Cannot access as its not a static member
            CompanyName = newCompanyName;
        }
    }
}
