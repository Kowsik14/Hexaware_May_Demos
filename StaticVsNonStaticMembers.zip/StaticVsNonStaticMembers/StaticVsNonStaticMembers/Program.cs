﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticVsNonStaticMembers
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Obj = new Employee();
            Obj.Name = "Mohsin";

            Employee Obj1 = new Employee();
            Obj1.Name = "Honey";
            
            Employee.CompanyName = "Hexaware";

            Obj.PrintEmployeeDetails();
            Obj1.PrintEmployeeDetails();

            Employee.ChangeCompany("Awesome Company");

            Obj.PrintEmployeeDetails();
            Obj1.PrintEmployeeDetails();

            Console.ReadKey();
        }
    }
}
