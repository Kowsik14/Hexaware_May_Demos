﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
namespace FileStreamAndStreamReaderStreamWriter
{
    class Program
    {
        static void Main(string[] args)
        {
            //WriteData();
            ReadData();

            Console.ReadKey();
        }

        private static void ReadData()
        {
            using (FileStream fileStream02 = new FileStream("E:\\test.txt", FileMode.Open, FileAccess.Read))
            {
                StreamReader streamReader = new StreamReader(fileStream02);
                int ch = streamReader.Read();
                while (ch > 0)
                {
                    Console.Write((char)ch);
                    ch = streamReader.Read();
                }
                //string data = streamReader.ReadToEnd();
                //Console.WriteLine(data);
                streamReader.Close();
                fileStream02.Close();
            }
        }

        private static void WriteData()
        {
            using (FileStream fileStream01 = new FileStream("E:\\test.txt", FileMode.Create, FileAccess.Write))
            {
                StreamWriter streamWriter = new StreamWriter(fileStream01);
                streamWriter.WriteLine("this is a Test");
                streamWriter.WriteLine("this is a Test");
                streamWriter.WriteLine("this is a Test");
                streamWriter.Flush();
                streamWriter.Close();
                fileStream01.Close();
            }
        }
    }
}
