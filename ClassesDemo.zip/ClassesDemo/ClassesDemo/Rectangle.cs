﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesDemo
{
    class Rectangle
    {
        public int Length, Breath;  //Field
        public int CalculateArea()  //Method
        {
            return Length * Breath;
        }
    }
}
