﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesDemo
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle Obj = new Rectangle();
            Obj.Length = 10;
            Obj.Breath = 5;

            int Area = Obj.CalculateArea();
            Console.WriteLine("Area = " + Area);

            Console.ReadKey();

        }
    }

    
}
namespace Syed
{
    class Program
    {

    }
}