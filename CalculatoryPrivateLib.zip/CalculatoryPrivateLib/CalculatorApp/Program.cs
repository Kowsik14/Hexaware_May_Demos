﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CalculatoryPrivateLib;
namespace CalculatorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator Obj = new Calculator();
            Console.WriteLine(Obj.Add(10, 20));
            Console.WriteLine(Obj.Multiply(10, 20));

            Console.ReadKey();
        }
    }
}
