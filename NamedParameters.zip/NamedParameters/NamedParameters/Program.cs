﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamedParameters
{
    class Program
    {
        static void Main(string[] args)
        {
            Print(101, "Jojo");
            Print(name: "Sam", _id: 101);

            Console.ReadKey();

        }

        static void Print(int _id, string name)
        {
            Console.WriteLine("Id=" + _id);
            Console.WriteLine("Name=" + name);
        }
    }
}
