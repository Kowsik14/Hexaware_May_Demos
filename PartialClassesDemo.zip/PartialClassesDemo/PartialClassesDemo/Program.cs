﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClassesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ATM Obj = new ATM();
            Obj.Deposit(1000);
            Obj.Withdraw(1000);

            Console.ReadKey();
        }
    }
}
