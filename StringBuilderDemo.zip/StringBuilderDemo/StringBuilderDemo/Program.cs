﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Text;
namespace StringBuilderDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder Obj = new StringBuilder();
            Obj.Append("Hello world !");
            Obj.Append("\nWelcome to Hexaware");
            Obj.Replace('!', '?');

            string result = Obj.ToString();
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
